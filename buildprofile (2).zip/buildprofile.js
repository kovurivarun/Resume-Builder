const form = document.getElementById("frstaccordian");



form.addEventListener("submit",function(event){
  event.preventDefault();
  const txtFirstName =form.querySelector("[name='firstName']");
  const txtLastName =form.querySelector("[name='lastName']");
  const txtDob =form.querySelector("[name='dateOfBirth']");
  const txtAddress =form.querySelector("[name='Address']");
 
  const pesonalSubmit = form.querySelector("[name='personalDataBtn']")
  const firstName = txtFirstName.value;
  const lastName = txtLastName.value;
  const dob = txtDob.value;
  const Address = txtAddress.value;
  const City = txtcity.value;
  const pin = txtpin.value;
  //if btnName = 'CertiSubmit' then sectionname = 'Certification'
  const payload={
    firstName,
    lastName,
    dob,
    Address,
    City,
    pin

  };
//   alert(email + " " + password);
  window.fetch(window?.config?.ApiUrls?.LOGIN,
    {
      method : "POST" ,
      body: JSON.stringify(payload),
      headers : {
        'Content- Type' : 'application/json'
      }
    }).then((response) => {
      console.log({response});
      if(response.status == true){
     
     alert("login successfully")
     console.log(response);
     window.location.href =
     window?.config?.AppRoutes?.SIGNUP;
      
    }

 

  })
  
  .catch((error ) =>{
    console.log(error);
    alert(JSON.stringify(payload));
  });
});

const contactForm = document.getElementById("secondaccordian");

contactForm.addEventListener("submit",function(event){
    event.preventDefault();
    const txtEmail =form.querySelector("[name='email']");
    const txtPhonenumber=form.querySelector("[name='phoneNumber']");
  const txtAlternatePhoneNumber =form.querySelector("[name='alternateNumber']");
  const txtLink =form.querySelector("[name='linkdin']");
  
  const submitbutton = form.querySelector("[name='submitButton']")
    const email = txtEmail.value;
    const phoneNumber = txtPhonenumber.value;
    const altPhoneNumber = txtAlternatePhoneNumber.value;
    const linkdin = txtLink.value;
    
    //if btnName = 'CertiSubmit' then sectionname = 'Certification'
    const payload={
      email,
      phoneNumber,
      altPhoneNumber,
      linkdin

    };
  //   alert(email + " " + password);
    window.fetch(window?.config?.ApiUrls?.LOGIN,
      {
        method : "POST" ,
        body: JSON.stringify(payload),
        headers : {
          'Content- Type' : 'application/json'
        }
      }).then((response) => {
        console.log({response});
     if(response.status == true){
       
       alert("login successfully")
       console.log(response);
       window.location.href =
       window?.config?.AppRoutes?.SIGNUP;
        
      }
    })
    
    .catch((error ) =>{
      console.log(error);
      alert(JSON.stringify(payload));
    });
  });


  const experienceForm = document.getElementById("thirdaccordion");

contactForm.addEventListener("submit",function(event){
    event.preventDefault();
    const txtCompany =form.querySelector("[name='companyName']");
    const txtPosition=form.querySelector("[name='position']");
    const txtDate =form.querySelector("[name='date']");
    const txtCurrentJob =form.querySelector("[name='currentJob']");
    const txtYes =form.querySelector("[name='yes']");
    const txtNo =form.querySelector("[name='no']");
  
  const submitbutton = form.querySelector("[name='submitButton']")
    const companyName = txtCompany.value;
    const position = txtPosition.value;
    const date = txtDate.value;
    const currentJob = txtCurrentJob.value;
    const yes = txtYes.value;
    const no = txtYes.value;
    
    //if btnName = 'CertiSubmit' then sectionname = 'Certification'
    const payload={
      companyName,
      position,
      date,
      currentJob,
      yes,
      no
    };
  //   alert(email + " " + password);
    window.fetch(window?.config?.ApiUrls?.LOGIN,
      {
        method : "POST" ,
        body: JSON.stringify(payload),
        headers : {
          'Content- Type' : 'application/json'
        }
      }).then((response) => {
        console.log({response});
     if(response.status == true){
       
       alert("login successfully")
       console.log(response);
       window.location.href =
       window?.config?.AppRoutes?.SIGNUP;
        
      }
    })
    
    .catch((error ) =>{
      console.log(error);
      alert(JSON.stringify(payload));
    });
  });


  const eForm = document.getElementById("thirdaccordion");

contactForm.addEventListener("submit",function(event){
    event.preventDefault();
    const txtCompany =form.querySelector("[name='companyName']");
    const txtPosition=form.querySelector("[name='position']");
    const txtDate =form.querySelector("[name='date']");
    const txtCurrentJob =form.querySelector("[name='currentJob']");
    const txtYes =form.querySelector("[name='yes']");
    const txtNo =form.querySelector("[name='no']");
  
  const submitbutton = form.querySelector("[name='submitButton']")
    const companyName = txtCompany.value;
    const position = txtPosition.value;
    const date = txtDate.value;
    const currentJob = txtCurrentJob.value;
    const yes = txtYes.value;
    const no = txtYes.value;
    
    //if btnName = 'CertiSubmit' then sectionname = 'Certification'
    const payload={
      companyName,
      position,
      date,
      currentJob,
      yes,
      no
    };
  //   alert(email + " " + password);
    window.fetch(window?.config?.ApiUrls?.LOGIN,
      {
        method : "POST" ,
        body: JSON.stringify(payload),
        headers : {
          'Content- Type' : 'application/json'
        }
      }).then((response) => {
        console.log({response});
     if(response.status == true){
       
       alert("login successfully")
       console.log(response);
       window.location.href =
       window?.config?.AppRoutes?.SIGNUP;
        
      }
    })
    
    .catch((error ) =>{
      console.log(error);
      alert(JSON.stringify(payload));
    });
  });

